# ParamsCalibrator

Siemens Curious Minds Software Summer School 2026 — track: **Procesare Semnal & Algoritmi**.

ML-based calibration of physical constants (motor winding heat-transfer coefficient) from
sensor data, benchmarked against classical calibration methods (GA, PSO, Levenberg-Marquardt,
EKF, Bayesian Optimization) across accuracy, speed, convergence robustness, scalability, and
real-time/streaming suitability. See `docs/proposal_en.md` / `docs/proposal_ro.md` for the full
technical proposal.

## Status

- [x] Physics simulator (1-node & 2-node motor thermal model) + synthetic data generator
- [ ] Baseline calibration methods (GA, PSO, LM, EKF, Bayesian Optimization)
- [ ] MLP calibration model
- [ ] Benchmark harness
- [ ] FastAPI microservice + Docker

## Project layout

```
src/
  simulator/    physics model, load profiles, synthetic dataset generation
  baselines/    GA / PSO / LM / EKF / Bayesian Optimization calibrators (WIP)
  ml/           feature extraction + MLP calibration model (WIP)
  benchmark/    benchmark harness across all methods x metrics (WIP)
  api/          FastAPI microservice (WIP)
tests/          pytest sanity checks
scripts/        CLI entry points (generate data, run benchmark, etc.)
data/           generated synthetic datasets (gitignored)
reports/figures/ validation plots and benchmark charts
```

## Setup

```
pip install -r requirements.txt
```

## Generate the synthetic datasets

```
python scripts/generate_datasets.py
```

## Run tests

```
pytest tests/ -v
```

## Modeling assumptions

No real Siemens hardware or proprietary data is used. The testbed is a synthetic motor winding
thermal model with constants drawn from illustrative, representative ranges for a small/medium
industrial motor (order-of-magnitude consistent with published motor thermal design literature,
e.g. IEC 60034 thermal classes) — not exact manufacturer or standard figures. This is stated
explicitly as a modeling assumption in the project proposal.
