#!/usr/bin/env python3
"""Generate the synthetic train/val/test datasets for both testbeds.

Usage:
    python scripts/generate_datasets.py
"""

import os
import sys
import time

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.simulator.data_generator import (
    generate_one_node_dataset,
    generate_two_node_dataset,
    save_dataset,
)

DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")

# (split_name, n_runs, seed)
ONE_NODE_SPLITS = [("train", 1200, 1001), ("val", 200, 1002), ("test", 200, 1003)]
TWO_NODE_SPLITS = [("train", 1200, 2001), ("val", 200, 2002), ("test", 200, 2003)]


def main():
    os.makedirs(DATA_DIR, exist_ok=True)

    print("Generating 1-node datasets...")
    for split, n_runs, seed in ONE_NODE_SPLITS:
        t0 = time.time()
        data = generate_one_node_dataset(n_runs=n_runs, seed=seed)
        path = os.path.join(DATA_DIR, f"motor_1node_{split}.npz")
        save_dataset(path, data)
        print(f"  {split}: {n_runs} runs -> {path} ({time.time() - t0:.1f}s)")

    print("Generating 2-node datasets...")
    for split, n_runs, seed in TWO_NODE_SPLITS:
        t0 = time.time()
        data = generate_two_node_dataset(n_runs=n_runs, seed=seed)
        path = os.path.join(DATA_DIR, f"motor_2node_{split}.npz")
        save_dataset(path, data)
        print(f"  {split}: {n_runs} runs -> {path} ({time.time() - t0:.1f}s)")

    print("Done.")


if __name__ == "__main__":
    main()
